package com.example.project3;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private boolean SMS_MSG = false;
    private String curDate, username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);
        connect();

        //sets action listeners for the buttons of the app.
        Button mButton;
        mButton = (Button) this.findViewById(R.id.newAcctButton);
        mButton.setOnClickListener(newUser());
        mButton = (Button) this.findViewById(R.id.loginButton);
        mButton.setOnClickListener(login());
        mButton = (Button) this.findViewById(R.id.noButton);
        mButton.setOnClickListener(smsOff());
        mButton = (Button) this.findViewById(R.id.yesButton);
        mButton.setOnClickListener(smsOn());

        //sets action listener for calendar
        CalendarView c = (CalendarView) this.findViewById(R.id.calendarView);
        c.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                curDate = String.valueOf(dayOfMonth);
            }
        });
        c.setOnClickListener(updateWorkouts());
    }


    public View.OnClickListener updateWorkouts()
    {
        RecyclerView r = (RecyclerView) this.findViewById(R.id.Recycler);
        readWorkouts(username);
        return null;
    }

    public View.OnClickListener newUser() {
        EditText user = (EditText) this.findViewById(R.id.editTextTextPassword2);
        EditText pass = (EditText) this.findViewById(R.id.editTextTextPassword);
        username = user.getText().toString();
        password = pass.getText().toString();
        System.out.println("Username: " + username + "Password: " + password);
        create(username, password);
        return null;
    }

    public View.OnClickListener login() {
        EditText user = (EditText) this.findViewById(R.id.editTextTextPassword2);
        EditText pass = (EditText) this.findViewById(R.id.editTextTextPassword);
        username = user.getText().toString();
        password = pass.getText().toString();
        System.out.println("Username: " + username + "Password: " + password);
        if(read(username, password))
        {
            //swap to main screen
        }
        else{
            return null;
        }
        return null;
    }


    public View.OnClickListener smsOn() {
        SMS_MSG = true;
        return null;
    }
    public View.OnClickListener smsOff(){
        SMS_MSG = false;
        return null;
    }






    /**
     * Connect to a sample database
     */
    public static void connect() {
        Connection conn = null;
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/INSERTDB.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);

            System.out.println("Connection to SQLite has been established.");
            // SQL statement for creating a new table
            String sql = "CREATE TABLE IF NOT EXISTS Users (\n"
                    + " id integer PRIMARY KEY,\n"
                    + " name text NOT NULL,\n"
                    + " pass text NOT NULL,\n"
                    + ");";
            String sql2 = "CREATE TABLE IF NOT EXISTS Workouts (\n"
                    + " id integer PRIMARY KEY,\n"
                    + " name text NOT NULL,\n"
                    + " exercises text NOT NULL,\n"
                    + " reps text NOT NULL,\n"
                    + " day text NOT NULL,\n"
                    + ");";

            try {
                Statement stmt = conn.createStatement();
                stmt.execute(sql);
                stmt.execute(sql2);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public boolean create(String u, String p) {
        String sql = "INSERT INTO employees(name, pass)";

        try{
            String url = "jdbc:sqlite:C:/sqlite/INSERTDB.db";
            Connection conn = DriverManager.getConnection(url);
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, u);
            pstmt.setString(2, p);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }

        //TODO swap views when user is created
        return true;
    }

    public boolean destroy() {

        return true;
    }

    public boolean update() {

        return true;
    }

    public boolean read(String u, String p) {
        String sql = "SELECT * FROM Users";

        try {
            String url = "jdbc:sqlite:C:/sqlite/INSERTDB.db";
            Connection conn = DriverManager.getConnection(url);
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);

            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t" +
                        rs.getString("name") + "\t" +
                        rs.getString("pass"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }

        //TODO swap views when verified
            return true;
    }
    public boolean readWorkouts(String username)
    {
        String sql = "SELECT * FROM Users";

        try {
            String url = "jdbc:sqlite:C:/sqlite/Workout.db";
            Connection conn = DriverManager.getConnection(url);
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);

            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t" +
                        rs.getString("name") + "\t" +
                        rs.getString("date"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }

        //TODO updates with workouts from the selected day
        return true;
    }
}
